import 'package:flutter/material.dart';

class Tema {
  // Cores
  static Color corPrimeira = Colors.deepPurpleAccent;
  static Color backgroundColor = Colors.grey[900]!;
  static Color buttonColor = Colors.deepPurpleAccent;
  static Color textColor = Colors.white;
  static Color borderColor = Colors.deepPurpleAccent;
  static Color buttonTextColor = Colors.white;
  static Color textoInputColor = Color.fromARGB(255, 49, 49, 49);
}
